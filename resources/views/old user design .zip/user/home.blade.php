@extends('user/master_layout') @section('data')
<div class="page-header-section">
   <div class="page-header-area pt-2">
      <div class="page-header-content">
         <div class="container-fluid" >
            <div class="row">
               <div class="col-sm-5" style="border-right: 1px solid #000;">
                  <div class="input-group mb-3 form-inline">
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">Surah/Chapter</span>
                     </div>
                     <select name="sura" id="surah" class="mr-1">
                     	<option hidden="" selected="">Select Chapter</option>
                     	@foreach ($surahs as $key)
                        <option value="{{$key->id}}">{{$key->surah_number}} - {{$key->surah_name}}</option>
                        
                        @endforeach
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white ml-1 mr-1">Juz</span>
                     </div>
                     <select name="juz" id="juz">
                     	@for(@$i=1;$i<=30;$i++)
                     	
                     		@if($surah->hizb==$i)
                     			<option value="{{$key->hizb}}" selected>{{$key->hizb}}</option>
                     		@endif
                     	
                     		<option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                  </div>
               </div>
               <div class="col-sm-7">
               </div>
            </div>
            <div class="row">
               <div class="col-sm-5" style="border-right: 1px solid #000;">
                  <div class="input-group mb-3 form-inline">
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">From verse</span>
                     </div>
                     <select name="verse" id="verse" class="mr-1">
                        @for(@$i=1;$i<=$surah->verses;$i++)
                     	  <option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">To verse</span>
                     </div>
                     <select name="toverse" id="toverse">
                        @for(@$i=1;$i<=$surah->verses;$i++)
                     	  <option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white  ml-1 mr-1">Raku</span>
                     </div>
                     <select name="hizb" id="hizb">
                       
                     </select>
                  </div>
               </div>
               <div class="col-sm-7">
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="container-fluid">
   <div class="row mt-5">
      <div class="col-sm-6 left" >
        <p id="translation">
            @foreach ($surah->verse as $verse)
            {{$verse->translation}}
            <span class="icon-round custom-number" ><span style="padding: 5px;">{{$verse->verse}}</span></span>
            @endforeach 
         </p>
      </div>
      <div class="col-sm-6 right" >
         <p class="pull-right" id="arabic" dir="rtl">
            @foreach ($surah->verse as $verse)
            {{$verse->arabic_immune}} <span class="icon-round custom-number" ><span style="padding: 5px;">{{$verse->verse}}</span></span>
            @endforeach
            
         </p>
      </div>
   </div>
</div>
<div class="page-header-section footer">
   <div class="container">
      <div class="row">
         <div class="page-header-area">
            <div class="page-header-content">
               <div class="main-control">
                  <div class="btn _previous">
                  </div>
                  <div class="btn _pause">
                  </div>
                  <div class="btn _next">
                  </div>
                  <div class="btn _timeline">
                     <span class="current-time">2:32</span>
                     <span class="timescope">
                     <span class="timescope-dot"></span>
                     </span>
                     <span class="end-time">4:00</span>
                  </div>
               </div>
              
            </div>
         </div>
      </div>
   </div>
</div>

	{{-- <audio controls autoplay >
@foreach($surah->verse as $verse)
               
               		  <source src="{{$ADMIN_ASSETS}}/audios/{{$verse->link_to_audio}}" type ="audio/mp3">
  					             	
               
			   @endforeach;
			   </audio> --}}
@endsection
@push('css') 
@endpush 
@push('js')
<script type="text/javascript">
    $('#surah').change(getSurah);
	
	function getSurah(){
		var surah_id=$('#surah').val();

      $.ajax({
      url:'{{ url('/get-surah') }}',
            type: 'post',
            data: {
              "_token": "{{ csrf_token() }}",
              "surah_id" : surah_id,
                  },
                   beforeSend: function(){
                       
                      },
                      complete: function(){
                         
                      },
                      success: function (response) 
                      {
                      	if(response!=0)
                      	{
                          var arabic='';
                          var translation='';
                          var returnedData = JSON.parse(response);
                          var i=1;
                          console.log(returnedData.verse);
                          returnedData.verse.forEach( function (item) {
                           arabic=arabic+item.arabic_immune+" <span class='icon-round custom-number' ><span style='padding: 5px;'>"+i+"</span></span> ";
                            translation=translation+item.translation+" <span class='icon-round custom-number' ><span style='padding: 5px;'>"+i+"</span></span> ";
                               i++;
                            });
                        	
                      	}
                        $("#arabic").html("");
                      	$("#arabic").append(arabic);
					               $("#translation").html("");
                        $("#translation").append(translation);
                      	// $("#arabic").append(view);
                      	// 
                      }
                    });
  }
</script>
@endpush
