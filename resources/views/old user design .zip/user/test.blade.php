@extends('user/master_layout') @section('data')

{{-- <div class="page-header-section">
   <div class="page-header-area pt-2">
      <div class="page-header-content">
         <div class="container-fluid" >
            <div class="row">
               <div class="col-sm-5" style="border-right: 1px solid #000;">
                  <div class="input-group mb-3 form-inline">
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">Surah/Chapter</span>
                       </div>
                     <select name="sura" id="surah" class="mr-1">
                     	<option hidden="" selected="">Select Chapter</option>
                     	@foreach ($surahs as $key)
                        <option value="{{$key->id}}">{{$key->surah_number}} - {{$key->surah_name}}</option>
                        
                        @endforeach
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white ml-1 mr-1">Juz</span>
                     </div>
                     <select name="juz" id="juz">
                     	@for(@$i=1;$i<=30;$i++)
                     	
                     		@if($surah->hizb==$i)
                     			<option value="{{$key->hizb}}" selected>{{$key->hizb}}</option>
                     		@endif
                     	
                     		<option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                  </div>
               </div>
               <div class="col-sm-7">
               </div>
            </div>
            <div class="row">
               <div class="col-sm-5" style="border-right: 1px solid #000;">
                  <div class="input-group mb-3 form-inline">
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">From verse</span>
                     </div>
                     <select name="verse" id="verse" class="mr-1">
                        @for(@$i=1;$i<=$surah->verses;$i++)
                     	  <option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white mr-1">To verse</span>
                     </div>
                     <select name="toverse" id="toverse">
                        @for(@$i=1;$i<=$surah->verses;$i++)
                     	  <option value="{{$i}}">{{$i}}</option>
                     	@endfor
                     </select>
                     <div class="input-group-prepend">
                        <span class="text-white  ml-1 mr-1">Raku</span>
                     </div>
                     <select name="hizb" id="hizb">
                       
                     </select>
                  </div>
               </div>
               <div class="col-sm-7">
               </div>
            </div>
         </div>
      </div>
   </div>
</div> --}}
<style>


.topnav {
  overflow: hidden;
  background-color: #fff;
   font-family: Roboto, sans-serif
}

.topnav a {
  float: left;
  display: block;
  color: #1a1a1a;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {

  color: #9c3;
}

.active {
  color: #9c3 !important;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a {display: none;}
  .topnav #logo {display: block;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
  <body>
    <section id="container">
      
      <div id="containerBody">
   
<div class="topnav" id="myTopnav">
  <a href="#" id="logo"><img src="{{$PUBLIC_ASSETS}}/img/forweb2.jpg" width="97px" height="35px" alt=""></a>
  <div class="inner-tabs" style="padding: 10px;">
    <a href="#home" class="active">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
  <a href="#about">About</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
  </div>
</div>
        <section class="panes_box">
          <section>
            <form>
              <section class="quran_menu">
                <ul>
                  <li>
                    <section class="nav_box">
                      <label>Sura / Chapter</label>
                      <select class=""
                        id="cmbSura" name="SuraID" style="width: 237px;">
                        @foreach ($surahs as $key)
                        <option value="{{$key->id}}">{{$key->surah_number}} - {{$key->surah_name}}</option>
                        @endforeach
                      </select>
                      <label>Juz</label>
                      <select class=""
                        id="cmbJuz" name="JuzID" style="width: 65px;">
                        @for(@$i=1;$i<=30;$i++)
                      
                        @if($surah->hizb==$i)
                          <option value="{{$key->hizb}}" selected>{{$key->hizb}}</option>
                        @endif
                      
                        <option value="{{$i}}">{{$i}}</option>
                      @endfor
                     </select>
                      </select>
                      <label>From Verse</label>
                      <select class="" 
                        id="cmbFVerse" name="VerseID" style="width: 65px;">
                          @for(@$i=1;$i<=$surah->verses;$i++)
                           <option value="{{$i}}">{{$i}}</option>
                          @endfor
                        
                      </select>
                      <label>To Verse</label>
                      <select class="" id="cmbTVerse" name="VerseID" style="width: 65px;">
                        @for(@$i=1;$i<=$surah->verses;$i++)
                        <option value="{{$i}}">{{$i}}</option>
                         @endfor
                      </select>
                      <label id="lblRukuHizbCap">Hizb</label>
                      <select class="" id="cmbHizb" name="HizbRuku" style="width: 65px;">
                        <option value="1">1</option>
                        <option value="2">1 &#188;</option>
                        <option value="3">1 &#189;</option>
                        <option value="4">1 &#190;</option>
                      </select>
                    </section>
                  </li>
                  <li>
                    <section class="script_box">
                      <label>Script</label>
                      <select class="" id="cmbScript" name="ResourceID">
                        <option value="15">IndoPak</option>
                        <option value="1">Usmani</option>
                      </select>
                      <a href="#" class="container_btn1" id="btnMAA" title="Arabic Audio">
                        <img id="btnMAA_Img" src="https://read.quranexplorer.com/public/Images/Quran/spacer.gif" alt="Mute Arabic Audio" />
                      </a>
                      <br />
                      <label>Reciter</label>
                      <select class="" id="cmbReciter" name="ResourceID">
                        <option value="4">Abdul-Baasit</option>
                      </select>
                    </section>
                  </li>
                  <li>
                    <section class="translate_box">
                      <p>
                        <label>Translation </label>
                      </p>
                      <p>
                        <select class="" id="cmbTranslation" name="ResourceID">
                          <option value="9">Deutsch</option>
                        </select>
                        <a href="javascript:void(0);" class="container_btn1" id="btnMTA" title="Translation Audio">
                          <img id="btnMTA_Img" src="https://read.quranexplorer.com/public/Images/Quran/spacer.gif" alt="Mute Translation Audio" />
                        </a>
                      </p>
                    </section>
                  </li>
                  <li>
                    <section class="memorization_box">
                      <div>
                        <p>
                          <label>Verse Repeat</label>
                          <select id="cmbVerseRepeat" class="">
                            <option>1</option>
                            <option>2</option>
                          </select>
                        </p>
                        <p>
                          <label>Range Repeat</label>
                          <select id="cmbRangeRepeat" class="">
                            <option>1</option>
                            <option>2</option>
                          </select>
                        </p>
                      </div>
                     
                    </section>
                  </li>
                  <li>
                    <section class="option_box">
                      <input id="chkAPNS" type="checkbox" checked="checked" value="" />
                      <label for="chkAPNS">Auto play next sura</label>
                    
                    </section>
                  </li>
                  <li>
                    <section class="ColorTheme_box">
                      <div id="CP_ForeColor">
                        <label style="padding-right:22px;">Fore Color </label>
                        <div id="CP_ForeColorInSide" style="width:1px; color:#000000; cursor:pointer; display:inline; font-family:Arial; font-size:21px;">
                          █
                        </div>
                        <select id="cmbFColor" style="width:30px; height:20px; margin-left:-5px; margin-top:-6px" class="">
                          <option style="background-color:#394a59" value="#394a59">&nbsp;</option>
                        </select>
                      </div>
                      <div id="CP_BackColor">
                        <label style="width:100px;">Select Color </label>
                        <div id="CP_BackColorInSide" style="width:1px; color:#C4ECBD; cursor:pointer; display:inline; font-family:Arial; font-size:21px;">
                          █
                        </div>
                        <select id="cmbBColor" style="width:30px; height:20px; margin-left:-5px; margin-top:-6px" class="">
                          <option style="background-color:#acc0c7" value="#acc0c7">&nbsp;</option>
                          <option style="background-color:#dad6cb" value="#dad6cb">&nbsp;</option>
                         
                        </select>
                      </div>
                    </section>
                  </li>
                </ul>
                
              </section>
              
              
              <audio id="qe_player_tf">
                <source id="QE_Tafseer_Player" src="" type="audio/mpeg" />
              </audio>
              <audio id="qe_player_sc">
                <source id="QE_Script_Player" src="" type="audio/mpeg" />
              </audio>
              <audio id="qe_player_tr">
                <source id="QE_Translation_Player" src="" type="audio/mpeg" />
              </audio>
              
              
              
             
            </form>
          </section>
          
          <section>
            <section class="quran_menu">
              <ul>
                <li>
                  <section class="search_cl">
                    <label>Chapter</label>
                    <select class="" id="cmbSearchSura" name="SuraID" style="width: 200px;">
                      <option value="">-- All Chapter --</option>
                      <option value="1">1 - Al-Fatiha</option>
                      <option value="2">2 - Al-Baqara</option>
                 
                     
                    </select>
                    <label>Language</label>
                    <select class="" id="cmbSearchLanguage" name="ResourceID" style="width: 200px;">
                      <option value="1">--- Usmani</option>
                      <option value="15">--- IndoPak</option>
               
                    </select>
                  </section>
                </li>
                <li>
                  
                </li>
              </ul>
            </section>
            
           
          </section>
          
       
        </section>
        
      </div>
    </section>


<script>
  

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>


<div class="container-fluid">
   <div class="row mt-5">
      <div class="col-sm-6 left" >
        <p id="translation">
            @foreach ($surah->verse as $verse)
            {{$verse->translation}}
            <span class="icon-round custom-number" ><span style="padding: 5px;">{{$verse->verse}}</span></span>
            @endforeach 
         </p>
      </div>
      <div class="col-sm-6 right" >
         <p class="pull-right" id="arabic" dir="rtl">
            @foreach ($surah->verse as $verse)
            {{$verse->arabic_immune}} <span class="icon-round custom-number" ><span style="padding: 5px;">{{$verse->verse}}</span></span>
            @endforeach
            
         </p>
      </div>
   </div>
</div>
<div class="page-header-section footer">
   <div class="container">
      <div class="row">
         <div class="page-header-area">
            <div class="page-header-content">
               <div class="main-control">
                  <div class="btn _previous">
                  </div>
                  <div class="btn _pause">
                  </div>
                  <div class="btn _next">
                  </div>
                  <div class="btn _timeline">
                     <span class="current-time">2:32</span>
                     <span class="timescope">
                     <span class="timescope-dot"></span>
                     </span>
                     <span class="end-time">4:00</span>
                  </div>
               </div>
              
            </div>
         </div>
      </div>
   </div>
</div>

	{{-- <audio controls autoplay >
@foreach($surah->verse as $verse)
               
               		  <source src="{{$ADMIN_ASSETS}}/audios/{{$verse->link_to_audio}}" type ="audio/mp3">
  					             	
               
			   @endforeach;
			   </audio> --}}
@endsection
@push('css') 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="{{$PUBLIC_ASSETS}}/css/style_nav.css">
@endpush 
@push('js')
<script type="text/javascript">

    $('#cmbSura').change(getSurah);
	
	function getSurah(){
		var surah_id=$('#cmbSura').val();
    console.log(surah_id);
      $.ajax({
      url:'{{ url('/get-surah') }}',
            type: 'post',
            data: {
              "_token": "{{ csrf_token() }}",
              "surah_id" : surah_id,
                  },
                   beforeSend: function(){
                       
                      },
                      complete: function(){
                         
                      },
                      success: function (response) 
                      {
                      	if(response!=0)
                      	{
                          var arabic='';
                          var translation='';
                          var returnedData = JSON.parse(response);
                          var i=1;
                          console.log(returnedData.verse);
                          returnedData.verse.forEach( function (item) {
                           arabic=arabic+item.arabic_immune+" <span class='icon-round custom-number' ><span style='padding: 5px;'>"+i+"</span></span> ";
                            translation=translation+item.translation+" <span class='icon-round custom-number' ><span style='padding: 5px;'>"+i+"</span></span> ";
                               i++;
                            });
                        	
                      	}
                        $("#arabic").html("");
                      	$("#arabic").append(arabic);
					               $("#translation").html("");
                        $("#translation").append(translation);
                      	// $("#arabic").append(view);
                      	// 
                      }
                    });
  }
</script>
@endpush
