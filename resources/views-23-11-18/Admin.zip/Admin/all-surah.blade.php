@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
        <div class="col-12">
            @if(isset($message))
            @if($message==true)
            <div class="alert alert-success">
                    <strong>Success!</strong> Surah is added.
            </div>
            @elseif($message==false)
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @endif
            @endif
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Data Export</h4>
                    <table id="example" class="display nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Surah Number</th>
                                    <th>Surah name</th>
                                    <th>Verses</th>
                                    <th>Description</th>
                                    <th>Creation Date</th>
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                               @foreach($surahs as $data)
                                <tr>
                                 <td>{{$data->surah_number}}</td> 
                                <td>{{$data->surah_name}}</td>   
                                <td>{{$data->verses}}</td>   
                                <td>{{$data->description}}</td>   
                                <td>{{$data->created_at}}</td> 
                                <td><a href="{{url('/admin/surah-edit')}}/{{$data->id}}">Edit</a> /<a href="{{url('/admin/surah-delete')}}/{{$data->id}}"> Delete</a> / <a href="{{url('/admin/surah-details')}}/{{$data->id}}"> Details </a></td>  
                                </tr>
                                @endforeach
                            </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>
@endsection

  @push('css') 
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
 
  @endpush 
 @push('js')  

 <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                responsive: {
                    details: {
                        renderer: function ( api, rowIdx, columns ) {
                            var data = $.map( columns, function ( col, i ) {
                                return col.hidden ?
                                    '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                        '<td>'+col.title+':'+'</td> '+
                                        '<td>'+col.data+'</td>'+
                                    '</tr>' :
                                    '';
                            } ).join('');
         
                            return data ?
                                $('<table/>').append( data ) :
                                false;
                        }
                    }
                }
            } );
        } );
 </script>
 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
@endpush 

