@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add Translators</h4>
               <form class="floating-labels m-t-40" method="POST" action="{{url('/admin/save-translators')}}">
                @csrf
                    <div class="form-group m-b-40">
                        <input type="text" name="translators_name" class="form-control" id="input1">
                        <span class="bar"></span>
                        <label for="input1">Translators Name <span class="form-errors" style="color:red;">{{ $errors->first('translators_name') }}</span></label>
                    </div>
                    <br>
                    <div class="form-group m-b-40">
                    <button type="submit" class="btn waves-effect waves-light btn-rounded btn-outline-success">Submit</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

  @push('css') 
  <link href="{{$ADMIN_ASSETS}}/dist/css/pages/floating-label.css" rel="stylesheet">
  
 @push('js')    


 @endpush 

