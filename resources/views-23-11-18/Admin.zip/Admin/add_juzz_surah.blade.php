@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
    <div class="col-12">
       <table id="example" class="display nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Surah Name</th>
                                    <th>Verse from</th>
                                    <th>Verse from</th>
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($surahs as $surah)
                                <tr>
                                    <td>{{$surah->surah_name}}</td>
                                    <form method="POST" action="{{url('/admin/save-juzz-surah')}}">
                                         @csrf
                                    <td> <input type="text" name="from_verse" class="form-control"> </td>
                                    <td><input type="text" name="to_verse" class="form-control"></td>
                                    <td><input type="submit" name="from_verse" class="btn btn-primary"></form></td>
                                    <td></td>
                                </tr>
                            @endforeach
                            </tbody>
                    </table>
    </div>
</div>

@endsection

  @push('css') 
  <link href="{{$ADMIN_ASSETS}}/dist/css/pages/floating-label.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
 @push('js')    
<script type="text/javascript">
   $(document).ready(function() {
            $('#example').DataTable( {
                responsive: {
                    details: {
                        renderer: function ( api, rowIdx, columns ) {
                            var data = $.map( columns, function ( col, i ) {
                                return col.hidden ?
                                    '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                        '<td>'+col.title+':'+'</td> '+
                                        '<td>'+col.data+'</td>'+
                                    '</tr>' :
                                    '';
                            } ).join('');
         
                            return data ?
                                $('<table/>').append( data ) :
                                false;
                        }
                    }
                }
            } );
        } );
</script>
 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
 @endpush 

