@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
        <div class="col-12">
            @if(isset($message))
            @if($message==true)
            <div class="alert alert-success">
                    <strong>Success!</strong> Surah is added.
            </div>
            @elseif($message==false)
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @endif
            @endif
            
           
        </div>
    </div>
@endsection

  @push('css') 
 
 
  @endpush 
 @push('js')  


 
@endpush 

