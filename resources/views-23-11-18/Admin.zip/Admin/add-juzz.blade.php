@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add Juz</h4>
               <form class="floating-labels m-t-40" method="POST" action="{{url('/admin/save-juz')}}">
                @csrf
                <div class="form-group m-b-40">
                        <input type="text" name="name" class="form-control" id="input1">
                           <span class="bar"></span>
                        <label for="input1">Juz Name <span class="form-errors" style="color:red;">{{ $errors->first('name') }}</span></label>
                    </div>
                 <div class="form-group m-b-40">
                        <input type="text" name="juz_number" class="form-control" id="input1">
                           <span class="bar"></span>
                        <label for="input1">Juz Number <span class="form-errors" style="color:red;">{{ $errors->first('juz_number') }}</span></label>
                    </div>
                
                   <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Select Starting Surah verses in Juz</h4>
                                <span class="form-errors" style="color:red;">{{ $errors->first('surah_id.*') }}</span><br/>
                                <span class="form-errors" style="color:red;">{{ $errors->first('verse_from.*') }}</span><br/>
                                
                                <div id="education_fields"></div>
                                <div id="content">
                                <div class="row">
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <select class="form-control" 
                                            onchange="get_verses(this.value)" id="surah_id" name="surah_id" required>
                                                    <option value="">Select Surah</option>
                                                    @foreach($surah as $key)
                                                    <option value="{{$key->id}}">{{$key->surah_name}}</option>
                                                    @endforeach
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                           <select required class="form-control" id="verse_from" name="verse_from">
                                                    <option value="">Verse From</option>
                                                    
                                                </select>
                                        </div>
                                    </div>
                                   
                                </div>

                            </div>
                        </div>
                   </div>
                    <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Select Ending Surah verses in Juz</h4>
                                <span class="form-errors" style="color:red;">{{ $errors->first('end_surah_id') }}</span><br/>
                                <span class="form-errors" style="color:red;">{{ $errors->first('verse_to') }}</span><br/>
                                
                                <div id="education_fields"></div>
                                <div id="content">
                                <div class="row">
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                            <select class="form-control" 
                                            onchange="get_verses(this.value)" id="surah_id" name="end_surah_id" required>
                                                    <option value="">Select Surah</option>
                                                    @foreach($surah as $key)
                                                    <option value="{{$key->id}}">{{$key->surah_name}}</option>
                                                    @endforeach
                                                </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3 nopadding">
                                        <div class="form-group">
                                           <select required class="form-control" id="verse_from" name="verse_to">
                                                    <option value="">Verse to</option>
                                                    
                                                </select>
                                        </div>
                                    </div>
                                   
                                </div>

                            </div>
                        </div>
                   </div>
                   {{-- <input type="button" id="copy" value=" copy "/> --}}
                   
                    <div class="form-group m-b-40">
                    <input type="submit" class="btn waves-effect waves-light btn-rounded btn-outline-success" value="Submit">
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

  @push('css') 
  <link href="{{$ADMIN_ASSETS}}/dist/css/pages/floating-label.css" rel="stylesheet">
  
 @push('js')    

<script src="{{$ADMIN_ASSETS}}/node_modules/dff/dff.js" type="text/javascript"></script>

<script type="text/javascript">
  function get_verses(id)
    {
       
       var from_verse='';
       $.ajax({
         url:'{{ url('admin/get-surah') }}',
               type: 'post',
               data: {
                 "_token": "{{ csrf_token() }}",
                 "surah_id" : id,
                     },
                      beforeSend: function(){
                        },
                         complete: function(){
                         },
                         success: function (response) 
                         {
                           if(response!=0)
                           {
                            var returnedData = JSON.parse(response);
                           for (i = 1; i <= returnedData.verses; i++) { 
                                   from_verse=from_verse+'<option value="'+i+'">'+i+'</option>';
                               }
                            $("#verse_from").html("");
                             $("#verse_from").append(from_verse); 
                            
                           }
                           else
                           {
   
                           }
                          
                         }
                       });

     }
    

</script>
 @endpush 

