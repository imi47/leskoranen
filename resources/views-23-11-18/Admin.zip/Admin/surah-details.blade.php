@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
        <div class="col-6">
                <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Translation</h4>
                            <p>
                                    @foreach ($surah->verse as $verse)
                                    {{$verse->translation}}
                                    <button type="button" class="btn waves-effect waves-light btn-rounded btn-xs btn-info">{{$verse->verse}}</button>
                                    @endforeach 
                                </p>
                        </div>
                       
                    </div>
        </div>
        <div class="col-6">
                <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Arabic</h4>
                            <p class="pull-right" dir="rtl">
                                    @foreach ($surah->verse as $verse)
                                   
                                    {{$verse->arabic_immune}} <button type="button" class="btn waves-effect waves-light btn-rounded btn-xs btn-info">{{$verse->verse}}</button>
                                    @endforeach
                                   
                                   
                                        </p>
                        </div>
                        
                        
                    </div>
            </div>
    </div>
    <div class="row">
            <div class="col-12">
                    <div class="example">
                            <div class="player" style="background-color:black;">
                                    <div class="title" style="color:white;"></div>
                                <div class="controls">
                                    <div class="play"></div>
                                    <div class="pause"></div>
                                    <div class="rew"></div>
                                    <div class="fwd"></div>
                                </div>
                                <div class="volume"></div>
                                <div class="tracker"></div>
                            </div>
                            <ul class="playlist hidden">\
                                <?php $i=0; ?>
                                @foreach ($surah->verse as $verse)
                                <li audiourl="{{$ADMIN_ASSETS}}/audios/{{$verse->link_to_audio}}">{{$verse->link_to_audio}}
                                <?php echo $i++; ?></li>
                                @endforeach
                            </ul>
                    
                        </div>
                   
            </div>
    </div>
@endsection

  @push('css') 
  
  <link href="{{$ADMIN_ASSETS}}/audio_player/css/styles.css" rel="stylesheet" type="text/css" />
  @endpush 
 @push('js')  
    <script type="text/javascript" src="{{$ADMIN_ASSETS}}/audio_player/js/jquery-ui-1.8.21.custom.min.js"></script>
    <script type="text/javascript" src="{{$ADMIN_ASSETS}}/audio_player/js/main.js"></script>
@endpush 

