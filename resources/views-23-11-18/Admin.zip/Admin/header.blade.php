<div class="preloader" style="display: none;">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Quran e Pak</p>
        </div>
</div>
<div id="main-wrapper">
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">
                        <!-- Logo icon -->
                        <b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            {{-- <img src="{{$ADMIN_ASSETS}}/images/logo-icon.png" alt="homepage" class="dark-logo">
                            <!-- Light Logo icon -->
                            <img src="{{$ADMIN_ASSETS}}/images/logo-light-icon.png" alt="homepage" class="light-logo"> --}}
                        </b>
                        <!--End Logo icon -->
                    </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto">
                        <li class="d-none d-md-block d-lg-block">
                            <a href="javascript:void(0)" class="p-l-15">
                               <h3>Quran e Pak</h3>
                                {{-- <!--This is logo text-->
                                <img src="{{$ADMIN_ASSETS}}/images/logo-light-text.png" alt="home" class="light-logo"> --}}
                            </a>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav my-lg-0">
                       <!-- User Profile -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown u-pro">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user-circle-o"></i>&nbsp;<span class="hidden-md-down">{{Session::get('admin_name')}}&nbsp;</span> </a>
                            <div class="dropdown-menu dropdown-menu-right animated flipInY">
                                <!-- text-->
                                <a href="javascript:void(0)" class="dropdown-item"><i class="ti-user"></i> My Profile</a>
                                <!-- text-->
                               <div class="dropdown-divider"></div>
                                <!-- text-->
                                <a href="javascript:void(0)" class="dropdown-item"><i class="ti-settings"></i> Account Setting</a>
                                <!-- text-->
                                <div class="dropdown-divider"></div>
                                <!-- text-->
                                <a href="{{url('/admin/logout')}}" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a>
                                <!-- text-->
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- End User Profile -->
                        <!-- ============================================================== -->
                        </ul>
                </div>
            </nav>
        </header>
        <div class="side-mini-panel" style="overflow: visible;">
            <ul class="mini-nav ps ps--theme_default" data-ps-id="67d54738-86eb-66a5-ccd4-4b0bbcce4a7b" style="overflow: hidden;">
                <div class="togglediv"><a href="javascript:void(0)" id="togglebtn" style=""><i class="ti-menu"></i></a></div>
                <!-- .Dashboard -->
                <li class="selected">
                    <a href="javascript:void(0)"><i class="icon-speedometer"></i></a>
                    <div class="sidebarmenu">
                        <!-- Left navbar-header -->
                        <h3 class="menu-title">Dashboard</h3>
                        
                        <ul class="sidebar-menu ps ps--theme_default" data-ps-id="714da34f-7a12-d752-8941-077940e79ded">
                            <li><a href="{{url('/admin/dashboard')}}" class="active">Home</a></li>
                            
                        <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
                        <!-- Left navbar-header end -->
                    </div>
                </li>
                <li class="">
                    <a href="javascript:void(0)"><i class="fa fa-user-circle-o"></i></a>
                    <div class="sidebarmenu">
                        <!-- Left navbar-header -->
                        <h3 class="menu-title">Roles</h3>
                        
                        <ul class="sidebar-menu ps ps--theme_default" data-ps-id="714da34f-7a12-d752-8941-077940e79ded">
                           <li><a href="{{url('/admin/add-recitors')}}" >Add Recitors</a></li>
                            <li><a href="{{url('/admin/add-translators')}}" >Add Translator</a></li>
                            <li><a href="{{url('/admin/all-roles')}}" >All Roles</a></li>
                            
                          <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
                        <!-- Left navbar-header end -->
                    </div>
                </li>
               {{--  <li class="">
                    <a href="javascript:void(0)"><i class="ti-book"></i></a>
                    <div class="sidebarmenu">
                        <!-- Left navbar-header -->
                        <h3 class="menu-title">Juz</h3>
                        
                        <ul class="sidebar-menu ps ps--theme_default" data-ps-id="714da34f-7a12-d752-8941-077940e79ded">
                            <li><a href="{{url('/admin/all-juz')}}" >All Juz</a></li>
                            <li><a href="{{url('/admin/create-juz')}}" >Add Juz</a></li>
                          <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
                        <!-- Left navbar-header end -->
                    </div>
                </li> --}}
                <li class="">
                    <a href="javascript:void(0)"><i class="icon-book-open"></i></a>
                    <div class="sidebarmenu">
                        <!-- Left navbar-header -->
                        <h3 class="menu-title">Surah</h3>
                        
                        <ul class="sidebar-menu ps ps--theme_default" data-ps-id="714da34f-7a12-d752-8941-077940e79ded">
                            <li><a href="{{url('/admin/all-surah')}}" >All Surah</a></li>
                            <li><a href="{{url('/admin/add-surah')}}" >Add Surah</a></li>
                          <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
                        <!-- Left navbar-header end -->
                    </div>
                </li>

                <li class="">
                    <a href="javascript:void(0)"><i class="fa fa-book"></i></a>
                    <div class="sidebarmenu">
                        <!-- Left navbar-header -->
                        <h3 class="menu-title">Verses</h3>
                        
                        <ul class="sidebar-menu ps ps--theme_default" data-ps-id="714da34f-7a12-d752-8941-077940e79ded">
                            <li><a href="{{url('/admin/all-verses')}}" >All Verses</a></li>
                            <li><a href="{{url('/admin/add-verse')}}" >Add Verse</a></li>
                          <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
                        <!-- Left navbar-header end -->
                    </div>
                </li>
               
                <!-- /.Dashboard -->
                <!-- .Apps -->
                
                <!-- .Multi level -->
            <div class="ps__scrollbar-x-rail" style="left: 0px; bottom: 0px;"><div class="ps__scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__scrollbar-y-rail" style="top: 0px; right: 0px;"><div class="ps__scrollbar-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></ul>
        </div>
       
        <div class="page-wrapper" style="min-height: 519px;">
            
            <div class="container-fluid">
                
                
                
            
        
        