</div>
</div>  
<footer class="footer">
       Ranglerz
    </footer>
    <!-- ============================================================== -->
    <!-- End footer -->
    <!-- ============================================================== -->
         
</div>
<script src="{{$ADMIN_ASSETS}}/node_modules/jquery/jquery-3.2.1.min.js"></script>
<!-- Bootstrap popper Core JavaScript -->
<script src="{{$ADMIN_ASSETS}}/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="{{$ADMIN_ASSETS}}/dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="{{$ADMIN_ASSETS}}/dist/js/custom.min.js"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->
<!--morris JavaScript -->
<!-- Popup message jquery -->
<!-- Chart JS -->
<script src="{{$ADMIN_ASSETS}}/dist/js/dashboard1.js"></script>
@stack('js')