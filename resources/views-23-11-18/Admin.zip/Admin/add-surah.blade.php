@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add Surah</h4>
               <form class="floating-labels m-t-40" method="POST" action="{{url('/admin/save-surah')}}">
                @csrf
                    <div class="form-group m-b-40">
                        <input type="text" name="surah_name" class="form-control" id="input1">
                        <span class="bar"></span>
                        
                        <label for="input1">Surah Name <span class="form-errors" style="color:red;">{{ $errors->first('surah_name') }}</span></label>
                    </div>
                    
                    <div class="form-group m-b-40">
                            <input type="text" name="surah_number" class="form-control" id="input1">
                            <span class="bar"></span>
                            <label for="input1">Surah Number in Quran-e-Kareem <span class="form-errors" style="color:red;">{{ $errors->first('surah_number') }}</span></label>
                    </div>
                    
                    {{-- <div class="form-group m-b-40">
                            <input type="text" name="hizb" class="form-control" id="input1">
                            <span class="bar"></span>
                            <label for="input1">Number of Hizb <span class="form-errors" style="color:red;">{{ $errors->first('hizb') }}</span></label>
                    </div>
                    
                    <div class="form-group m-b-40">
                            <input type="text" name="raku" class="form-control" id="input1">
                            <span class="bar"></span>
                            <label for="input1">Number of Raku  <span class="form-errors" style="color:red;">{{ $errors->first('raku') }}</span></label>
                    </div> --}}
                   
                    <div class="form-group m-b-40">
                            <input type="text" name="verses" class="form-control" id="input1">
                            <span class="bar"></span>
                            <label for="input1">Number of Verses <span class="form-errors" style="color:red;">{{ $errors->first('verses') }}</span></label>
                    </div>
                    
                    <div class="form-group m-b-5">
                            <textarea class="form-control" name="description" rows="4" id="input7"></textarea>
                            <span class="bar"></span>
                            <label for="input7">Surah Descriprion</label>
                    </div>

                    <br>
                    <div class="form-group m-b-40">
                    <button type="submit" class="btn waves-effect waves-light btn-rounded btn-outline-success">Submit</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

  @push('css') 
  <link href="{{$ADMIN_ASSETS}}/dist/css/pages/floating-label.css" rel="stylesheet">
  
 @push('js')    


 @endpush 

