@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Add Verse</h4>
               <form class="floating-labels m-t-40" enctype="multipart/form-data" method="POST" action="{{url('/admin/save-verse')}}">
                @csrf
                    <div class="form-group m-b-40">
                        <input type="text" name="arabic_immune" class="form-control" id="input1">
                        <span class="bar"></span>
                        
                        <label for="input1">Arabic with Immune<span class="form-errors" style="color:red;">{{ $errors->first('arabic_immune') }}</span></label>
                    </div>
                    
                    <div class="form-group m-b-40">
                            <input type="text" name="arabic_no_immune" class="form-control" id="input1">
                            <span class="bar"></span>
                            <label for="input1">Arabic without Immune<span class="form-errors" style="color:red;">{{ $errors->first('arabic_no_immune') }}</span></label>
                    </div>
                   
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group m-b-40">
                                <input type="text" name="translation" class="form-control" id="input1">
                                <span class="bar"></span>
                                <label for="input1">Norvigion translation <span class="form-errors" style="color:red;">{{ $errors->first('translation') }}</span></label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group m-b-40">
                                <select name="translator_id" class="form-control p-0" id="input6">
                                    <option></option>
                                    @foreach($translator as $data)
                                    <option value="{{$data->id}}">{{$data->name}}</option>
                                    @endforeach
                                </select><span class="bar"></span>
                                <label for="input6">Select Translator Name  <span class="form-errors" style="color:red;">{{ $errors->first('translator_id') }}</span></label>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group m-b-40">
                                 <label for="input1">Link to audio clip<span class="form-errors" style="color:red;">{{ $errors->first('link_to_audio') }}</span></label>
                                 <br/>
                                <input type="file" name="link_to_audio" class="form-control" >
                                <span class="bar"></span>
                               
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group m-b-40">
                                <select name="recitor_id" class="form-control p-0" id="input6">
                                    <option></option>
                                    @foreach($recitors as $data)
                                    <option value="{{$data->id}}">{{$data->name}}</option>
                                    @endforeach
                                </select><span class="bar"></span>
                                <label for="input6">Select Recitor Name <span class="form-errors" style="color:red;">{{ $errors->first('recitor_id') }}</span></label>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                         <div class="col-md-2">
                            <div class="form-group m-b-40">
                                <select name="juzz_number" class="form-control p-0" >
                                    <option hidden=""></option>
                                     @for(@$i=1;$i<=30;$i++)
                                      <option value="{{$i}}">{{$i}}</option>
                                      @endfor
                                 </select><span class="bar"></span>
                                <label>Select Juz </label>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group m-b-40">
                               <input type="text" name="raku" class="form-control" id="input1">
                                <span class="bar"></span>
                                <label for="input1">Raku <span class="form-errors" style="color:red;">{{ $errors->first('translation') }}</span></label>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group m-b-40">
                                <select name="surah_id" onchange="getval(this);" class="form-control p-0" >
                                    <option></option>
                                    @foreach($surahs as $data)
                                    <option value="{{$data->id}}">{{$data->surah_name}} [{{$data->surah_number}}]</option>
                                    @endforeach
                                 </select><span class="bar"></span>
                                <label>Select Surah </label>
                            </div>
                        </div>
                        <div class="col-md-6" id="response">
                            <span class="form-errors" style="color:red;">{{ $errors->first('surah_id') }}</span><br>
                            <span class="form-errors" style="color:red;">{{ $errors->first('hizb') }}</span><br>
                            <span class="form-errors" style="color:red;">{{ $errors->first('raku') }}</span><br>
                            <span class="form-errors" style="color:red;">{{ $errors->first('verses') }}</span>
                        </div>
                    </div>
                    <div class="form-group m-b-5">
                            <textarea class="form-control" name="description" rows="4" ></textarea>
                            <span class="bar"></span>
                            <label >Verse Descriprion</label>
                    </div>

                    <br>
                    <div class="form-group m-b-40">
                    <button type="submit" class="btn waves-effect waves-light btn-rounded btn-outline-success">Submit</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

  @push('css') 
  <link href="{{$ADMIN_ASSETS}}/dist/css/pages/floating-label.css" rel="stylesheet">
  @endpush 
 @push('js')    
<script>
    function getval(sel)
{
    $.ajax({
        url:'{{url('/admin/get-surah-details')}}',
                type: 'POST',
                data: {
                  "_token": "{{ csrf_token() }}",
                  "id" : sel.value
                },
              success:function(response) {
                  
             document.getElementById("response").innerHTML = response ;
              }
    
            });
}
</script>

 @endpush 

