@extends('Admin/master_layout')
@section('data')

<br><br>
<div class="row">
        <div class="col-12">
            @if(isset($message) )
            @if($message==1)
            <div class="alert alert-success">
                    <strong>Success!</strong> Recitor is added.
            </div>
            @elseif($message==3)
            <div class="alert alert-success">
                    <strong>Success!</strong> Translator is added.
            </div>
            @elseif($message==2)
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @endif
            @endif
            @if(isset($_GET['message']))
            @if($_GET['message']==4)
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Recitor is blocked.
                </div>
            @elseif($_GET['message']==5)
            <div class="alert alert-success">
                    <strong>Success!</strong> Recitor is active.
                    </div>
            @elseif($_GET['message']==6)
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Translator is blocked.
                </div>
            @elseif($_GET['message']==7)
            <div class="alert alert-success">
                    <strong>Success!</strong> Translator is active.
                    </div>
            @elseif($_GET['message']==8)
            <div class="alert alert-success">
                    <strong>Success!</strong> Name is updated Successfully.
                    </div>
            @endif
            @endif
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Roles</h4>
                    <table id="example" class="display nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Creation Date</th>
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                               @foreach($roles as $data)
                                <tr>
                                <td>{{$data->name}}</td>   
                                <td>{{$data->role}}</td>   
                                 <td>{{$data->created_at}}</td> 
                                <td><a href="{{url('/admin/')}}/{{$data->role}}/edit/{{$data->id}}">Edit</a> /
                                    @if($data->status=="active")
                                    <a href="{{url('/admin/')}}/{{$data->role}}/block/{{$data->id}}"><span style="color:red;">Block</span>
                                    @elseif($data->status=="block")
                                    <a href="{{url('/admin/')}}/{{$data->role}}/active/{{$data->id}}"><span style="color:green;">Active</span>
                                    @endif
                                    </a></td>  
                                </tr>
                                @endforeach
                            </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>
@endsection

  @push('css') 
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
 
  @endpush 
 @push('js')  

 <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                responsive: {
                    details: {
                        renderer: function ( api, rowIdx, columns ) {
                            var data = $.map( columns, function ( col, i ) {
                                return col.hidden ?
                                    '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                        '<td>'+col.title+':'+'</td> '+
                                        '<td>'+col.data+'</td>'+
                                    '</tr>' :
                                    '';
                            } ).join('');
         
                            return data ?
                                $('<table/>').append( data ) :
                                false;
                        }
                    }
                }
            } );
        } );
 </script>
 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
@endpush 

