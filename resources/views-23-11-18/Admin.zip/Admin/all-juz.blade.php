@extends('Admin/master_layout')
@section('data')
@php
use  App\Utilities;
@endphp
<br><br>
<div class="row">
        <div class="col-12">
            @if(isset($_GET['message']))
            @if($_GET['message']=="blocked")
            <div class="alert alert-warning">
                    <strong>Attention!</strong> Juz is blocked.
            </div>
            @elseif($_GET['message']=="error")
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @elseif($_GET['message']=="unblocked")
            <div class="alert alert-success">
                    <strong>Attention!</strong> Juz is unblocked.
                  </div>
            @elseif($_GET['message']=="error")
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @elseif($_GET['message']=="error")
            <div class="alert alert-danger">
                    <strong>Attention!</strong> Some thing went wrong. Surah not added.
                  </div>
            @endif
            @endif
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Data Export</h4>
                    <table id="example" class="display nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Juz Number</th>
                                    <th>Juz name</th>
                                    <th>Starting Surah</th>
                                    <th>Creation Date</th>
                                    <th>Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                              @foreach($juzs as $data)
                                <tr>
                                 <td>{{$data->juz_number}}</td> 
                                <td>{{$data->juz_name}}</td>   
                                <td>{{Utilities::get_surah_name($data->surah_id)}} from verse number {{$data->from_verse}}</td>   
                                <td>{{$data->created_at}}</td> 
                                <td><a href="{{url('/admin/juz/edit')}}/{{$data->id}}">Edit</a> /
                                    @if($data->status==1)
                                    <a href="{{url('/admin/juz/block')}}/{{$data->id}}"> Block</a>
                                    @else
                                     <a href="{{url('/admin/juz/unblock')}}/{{$data->id}}"> Unblock</a>
                                    @endif
                                        / <a href="{{url('/admin/juz/details')}}/{{$data->id}}"> Details </a></td>  
                                </tr>
                                @endforeach
                            </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>
@endsection

  @push('css') 
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
 
  @endpush 
 @push('js')  

 <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                responsive: {
                    details: {
                        renderer: function ( api, rowIdx, columns ) {
                            var data = $.map( columns, function ( col, i ) {
                                return col.hidden ?
                                    '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                        '<td>'+col.title+':'+'</td> '+
                                        '<td>'+col.data+'</td>'+
                                    '</tr>' :
                                    '';
                            } ).join('');
         
                            return data ?
                                $('<table/>').append( data ) :
                                false;
                        }
                    }
                }
            } );
        } );
 </script>
 <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
@endpush 

